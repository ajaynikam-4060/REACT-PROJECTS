import React from "react";
import * as classes from "./SudokuBox.module.css";

const SudokuBox = () => {
  return <div className={classes.SudokuBox}></div>;
};
export default SudokuBox;
